# Sunny Studios Project

from array import array
import numpy as np

import pygame
import moderngl

hexPalette = np.array([ # 26
    [0.41960785, 0.4117647, 0.45490196],  # #6b6974
    [0.23529412, 0.23137255, 0.27058824],  # #3c3b45
    [0.1372549,  0.11372549, 0.14117647],  # #231d24
    [0.0,        0.0,        0.0],         # #000000
    [0.58039216, 0.23529412, 0.04705882],  # #943c0c
    [0.4862745,  0.16470589, 0.09803922],  # #7c2a19
    [0.41960785, 0.2509804,  0.23921569],  # #6b403d
    [0.3019608,  0.02745098, 0.11372549],  # #4d071d
    [0.19215687, 0.09411765, 0.11764706],  # #31181e
    [0.4862745,  0.3019608,  0.09803922],  # #7c4d19
    [0.36078432, 0.1254902,  0.03921569],  # #5c200a
    [0.8,        0.6313726,  0.44313726],  # #cca171
    [0.6039216,  0.4,        0.32941177],  # #9a6654
    [0.33333334, 0.3882353,  0.3019608],   # #55634d
    [0.24705882, 0.2627451,  0.22352941],  # #3f4339
    [0.22745098, 0.0,        0.0],         # #3a0000
    [0.34901962, 0.0,        0.0],         # #590000
    [0.4862745,  0.01176471, 0.0],         # #7c0300
    [0.7529412,  0.16862746, 0.09411765],  # #c02b18
    [0.8784314,  0.25882354, 0.09019608],  # #e04217
    [0.9490196,  0.42745098, 0.12156863],  # #f26d1f
    [0.1254902,  0.09019608, 0.15294118],  # #201727
    [0.14901961, 0.10588235, 0.18039216],  # #261b2e
    [0.21960784, 0.1764706,  0.2627451],   # #382d43
    [0.37254903, 0.18431373, 0.27058825],  # #5f2f45
    [0.627451,   0.18431373, 0.2509804],   # #a02f40
    [0.99215686, 0.44705883, 0.30588236],  # #fd724e
], dtype='f4')

vert_shader  = '''
#version 330 core

in vec2 vert;
in vec2 texcoord;
out vec2 uvs;

void main() {
    uvs = texcoord;
    gl_Position = vec4(vert, 0.0, 1.0);
}
'''

frag_shader = '''
#version 330 core

uniform sampler2D tex;


in vec2 uvs;
out vec4 f_color;

void main() {
    vec3 color = texture(tex, uvs).rgb;

    float min_dist = 1000.0;
    vec3 closest = vec3(0.0);



    f_color = vec4(color, 1.0);
}
'''
# uniform vec3 palette[27];
    # for (int i = 0; i < 27; ++i){
    #     float dist = distance(color, palette[i]);
    #     if (dist < min_dist){
    #         min_dist = dist;
    #         closest = palette[i];
    #     }
    # }

screen = None
display = None
ctx = None
quad_buffer = None
program = None
render_object = None
SCREEN_RECT = None


def SetUpScreen(WIDTH, HEIGHT):
    global screen,display,ctx,quad_buffer,program,render_object,SCREEN_RECT
    screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.OPENGL | pygame.DOUBLEBUF | pygame.FULLSCREEN | pygame.SCALED)
    # screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.OPENGL | pygame.DOUBLEBUF)
    display = pygame.Surface((WIDTH,HEIGHT))
    SCREEN_RECT = pygame.Rect(0, 0, WIDTH, HEIGHT)
    ctx = moderngl.create_context()

    quad_buffer = ctx.buffer(data=array("f", [
        # position (x,y), uv coords (x, y)
        -1.0, 1.0, 0.0, 0.0, # Top left
        1.0, 1.0, 1.0, 0.0, # top right
        -1.0, -1.0, 0.0, 1.0, # bottom left
        1.0, -1.0, 1.0, 1.0, # bottom right
    ]))

    program = ctx.program(vertex_shader=vert_shader, fragment_shader=frag_shader)
    render_object = ctx.vertex_array(program, [(quad_buffer, '2f 2f', 'vert', 'texcoord')])


def surf_to_texture(surf):
    tex = ctx.texture(surf.get_size(), 4)
    tex.filter = (moderngl.NEAREST, moderngl.NEAREST)
    tex.swizzle = 'BGRA'
    tex.write(surf.get_view('1'))
    return tex

def RenderFrame():
    frame_tex = surf_to_texture(display)
    frame_tex.use(0)
    program['tex'] = 0
    # program['palette'].write(hexPalette.tobytes())
    render_object.render(mode=moderngl.TRIANGLE_STRIP)

    pygame.display.flip()

    frame_tex.release()