# Sunny Studios Project

import random
import pygame
import numpy as np
import Modules.lighting as lt
import Modules.objectManager as om
import math

def recolor_non_transparent(surface, new_color):
    # return surface
    # Convert surface to include per-pixel alpha if it doesn't already
    surface = surface.convert_alpha()

    # Extract the pixels as a 3D array
    arr = pygame.surfarray.pixels3d(surface)
    alpha = pygame.surfarray.pixels_alpha(surface)

    # Create a color array
    r, g, b = new_color
    mask = alpha > 0
    arr[..., 0][mask] = r
    arr[..., 1][mask] = g
    arr[..., 2][mask] = b

    # Unlock the surface
    del arr
    del alpha

    return surface


GenRate = 'High'
LowGenModifier = 4
originalGenRates = {}

particleGenerators = {}
disabledGenerators = {}

# ps.CreateGenerator("MenuMouseHighlight", 400, 300, r"Assets\Particles\hpStarPar1.png", (242, 109, 31), [[-5, 5],[-5,5]], [0.5, 0], [0.1, 1], 2, [0, 0], [0, 0], {
#       "Twinkle": 10})

# CreateGenerator(name, x, y, image, (r, g, b), [[minX, maxX],[minY,maxY]], [start, end], [delayBetInSec, genPer], lifetimeInSecs, [xAcel, yAcel], [bbX, bbY], {})
def CreateGenerator(name, x, y, image, color, velocity, size, rate, lifetime, aceleration, boundbox, specialProps):
    particleGenerators[name] =[{
        "x": x,
        "y": y,
        "image": pygame.image.load(image),
        "velocity": velocity,
        "size": size,
        "rate": rate,
        "lifetime": lifetime,
        "aceleration": aceleration,
        "posRandom": boundbox,
        "genCounter": 0,
        "special": specialProps,
        'color': color,
        'Disabled': False,
    }, []]
    originalGenRates[name] = rate.copy()
    if GenRate == 'Low': # divide the spawnrate by 4
        particleGenerators[name][0]['rate'][0] *= LowGenModifier
    elif GenRate == 'None': # Disable
        disabledGenerators[name] = [particleGenerators[name][0],[]]
        particleGenerators[name][0]['special']['NoMoreGen'] = True
    particleGenerators[name][0]['image'] = recolor_non_transparent(particleGenerators[name][0]['image'], color)
    if specialProps.get('Surface'):
        particleGenerators[name][0]['image'] = specialProps['Surface']

def GenRateChange(newRate):
    global GenRate, particleGenerators, disabledGenerators
    GenRate = newRate

    genEnableQuene = []
    if newRate == 'High':
        for i in disabledGenerators:
            disabledGenerators[i][0]['rate'] = originalGenRates[i].copy()
            if disabledGenerators[i][0]['Disabled'] == False:
                genEnableQuene.append(i)
    elif newRate == 'Low':
        for gen in particleGenerators:
            particleGenerators[gen][0]['rate'][0] = originalGenRates[gen].copy()[0] * LowGenModifier
        for gen in disabledGenerators:
            disabledGenerators[gen][0]['rate'][0] = originalGenRates[gen].copy()[0] * LowGenModifier
    elif GenRate == 'None': # Disable
        for name in particleGenerators:
            disabledGenerators[name] = [particleGenerators[name][0],[]]
            particleGenerators[name][0]['special']['NoMoreGen'] = True
    
    for i in genEnableQuene:
        EnableGenerator(i)

def EditGenerator(name, property, value):
    if (particleGenerators.get(name)):
        if (particleGenerators[name][0][property]):
            particleGenerators[name][0][property] = value

def DisableGenerator(name):
    if particleGenerators.get(name):
        disabledGenerators[name] = [particleGenerators[name][0],[]]
        particleGenerators[name][0]['special']['NoMoreGen'] = True
        particleGenerators[name][0]['Disabled'] = True

def EnableGenerator(name):
    if disabledGenerators.get(name):
        if not GenRate == 'None':
            particleGenerators[name] = [disabledGenerators[name][0],[]]
            particleGenerators[name][0]['Disabled'] = False
            del particleGenerators[name][0]['special']['NoMoreGen'] 
            del disabledGenerators[name]
        else:
            disabledGenerators[name][0]['Disabled'] = False

def DeleteGenerator(name):
    if particleGenerators.get(name):
        del particleGenerators[name]
        del originalGenRates[name]

def MoveGenerator(name, newX, newY):
    if (particleGenerators.get(name)):
        particleGenerators[name][0]['x'] = newX
        particleGenerators[name][0]['y'] = newY


def HandleParticles(deltaTime, screen, screenrect):
    deleteGeneratorsQuene = []
    for gen in particleGenerators:
        particleGenerators[gen][0]['genCounter'] += deltaTime
        ## Handle Generation of new particles and management of generators
        if (particleGenerators[gen][0]['genCounter'] >= particleGenerators[gen][0]['rate'][0]) and not(particleGenerators[gen][0]['special'].get('NoMoreGen')):
            particleGenerators[gen][0]['genCounter'] = 0

            if (particleGenerators[gen][0]['special'].get('OneUse')):
                del particleGenerators[gen][0]['special']['OneUse']
                particleGenerators[gen][0]['special']['NoMoreGen'] = True

            for i in range(particleGenerators[gen][0]['rate'][1]):

                useAltImage = False
                if (particleGenerators[gen][0]['special'].get('RandomImage')):
                    useAltImage = pygame.image.load(particleGenerators[gen][0]['special']['RandomImage'][random.randint(0, len(particleGenerators[gen][0]['special']['RandomImage'])-1)])

                # --- create particles ---
                particleGenerators[gen][1].append([
                    # Position
                    particleGenerators[gen][0]['x'] + random.randint(-particleGenerators[gen][0]['posRandom'][0], particleGenerators[gen][0]['posRandom'][0]), # Starting X position
                    particleGenerators[gen][0]['y'] + random.randint(-particleGenerators[gen][0]['posRandom'][1], particleGenerators[gen][0]['posRandom'][1]), # Starting Y Position
                    # Velocity
                    random.randint(particleGenerators[gen][0]['velocity'][0][0], particleGenerators[gen][0]['velocity'][0][1]) / 10, ## X 
                    random.randint(particleGenerators[gen][0]['velocity'][1][0], particleGenerators[gen][0]['velocity'][1][1]) / 10, ## Y
                    # size
                    particleGenerators[gen][0]['size'][0],
                    # Lifetime
                    0,
                    # Flipped
                    False,
                    # Alt Image
                    useAltImage,
                ])
        elif (particleGenerators[gen][0]['special'].get('NoMoreGen') and (len(particleGenerators[gen][1]) == 0)):
            deleteGeneratorsQuene.append(gen)

        ## Handle movement of particles
        for particle in range(len(particleGenerators[gen][1])):
            if len(particleGenerators[gen][1]) > particle:
                particleGenerators[gen][1][particle][5] += deltaTime
                if (particleGenerators[gen][1][particle][5] > particleGenerators[gen][0]['lifetime']): # particle dies
                    particleGenerators[gen][1].pop(particle)

                else: # particle doesnt die
                    particleGenerators[gen][1][particle][2] += particleGenerators[gen][0]['aceleration'][0]
                    particleGenerators[gen][1][particle][3] += particleGenerators[gen][0]['aceleration'][1]

                    particleGenerators[gen][1][particle][0] += particleGenerators[gen][1][particle][2] * deltaTime * 40
                    particleGenerators[gen][1][particle][1] += particleGenerators[gen][1][particle][3] * deltaTime * 40

                    # size
                    particleGenerators[gen][1][particle][4] = (particleGenerators[gen][1][particle][4] + ((deltaTime) * (particleGenerators[gen][0]['size'][1] - particleGenerators[gen][1][particle][4])))
                    
                    particleGenerators[gen][1][particle][4] = max(particleGenerators[gen][1][particle][4], 0)
                    
                    imageToScale = particleGenerators[gen][0]['image']

                    # Check if particle uses different image / replace image with one for individual
                    if not particleGenerators[gen][1][particle][7] == False:
                        imageToScale = (recolor_non_transparent(particleGenerators[gen][1][particle][7], particleGenerators[gen][0]['color']))

                    sizeToUse = particleGenerators[gen][1][particle][4]

                    imageToUse = pygame.transform.scale_by(imageToScale, sizeToUse)
                    if (particleGenerators[gen][0]['special'].get('Twinkle')):
                        if (random.randint(0, particleGenerators[gen][0]['special']['Twinkle']) == 0):
                            particleGenerators[gen][1][particle][6] = not particleGenerators[gen][1][particle][6]
                    

                    # Check if particle is flipped
                    if particleGenerators[gen][1][particle][6] == True:
                        imageToUse = pygame.transform.flip(imageToUse, True, False)
                    
                    imageRect = imageToUse.get_rect()

                    xWorldOffset = om.screenOffset[1]
                    yWorldOffset = om.screenOffset[1]
                    if (particleGenerators[gen][0]['special'].get('ScreenItem')):
                        xWorldOffset = 0
                        yWorldOffset = 0
                    # render
                    if (imageRect.colliderect(screenrect)):
                        screen.blit(
                            imageToUse,
                            (
                                (particleGenerators[gen][1][particle][0] - imageToUse.get_width() / 2) + xWorldOffset,
                                (particleGenerators[gen][1][particle][1] - imageToUse.get_height() / 2) + yWorldOffset
                            )
                        )
                    
                    if (particleGenerators[gen][0]['special'].get('Glow')):
                        lt.createLight(screen, (particleGenerators[gen][0]['special']['Glow'][0] * (particleGenerators[gen][0]['lifetime'] - particleGenerators[gen][1][particle][5])), [particleGenerators[gen][1][particle][0] + om.screenOffset[0], particleGenerators[gen][1][particle][1] + om.screenOffset[0]], particleGenerators[gen][0]['special']['Glow'][1])



    for delGen in deleteGeneratorsQuene:
        if particleGenerators.get(delGen):
            del particleGenerators[delGen]

