# Sunny Studios Project

import pygame
import numpy as np


activeAnimations = {}


def play(name, animation, dt):
    if not activeAnimations.get(name): # if the animation doesnt exist then create it
        activeAnimations[name] = [animation, 0]

    else:                
    ### animation exists, begin processing
        activeAnimations[name][1] += dt

    selected = activeAnimations[name][0][0]
    for i in activeAnimations[name][0]:
        if (i[1] <= activeAnimations[name][1]):
            selected = i

    if selected[0] == 'done':
        del activeAnimations[name]
        return 'done'
    elif selected[0] == 'loop':
        activeAnimations[name][1] = 0
        selected = activeAnimations[name][0][0]

    return selected[0]
    
def stop(name):
    if activeAnimations.get(name):
        del activeAnimations[name]

