# Sunny Studios Project

import pygame
import random
import numpy as np



def circle_surf(radius,color):
    surf = pygame.Surface((radius * 2, radius *2))
    pygame.draw.circle(surf, color, (radius, radius), radius)
    surf.set_colorkey((0,0,0))
    return surf
# def circle_surf(radius, color):
#     surf = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)  # Enable per-pixel alpha
#     pygame.draw.circle(surf, color, (radius, radius), radius)
#     return surf

def rect_surf(xSize, ySize,color):
    surf = pygame.Surface((xSize, ySize))    
    surf.fill(color)
    surf.set_colorkey((0,0,0))
    return surf

def blit_add_no_stack(dest, src, pos):
    dest_array = pygame.surfarray.pixels3d(dest)
    src_array = pygame.surfarray.array3d(src)

    x, y = map(int, pos)
    w, h = map(int, src.get_size())

    # Sanity bounds
    if x < 0 or y < 0 or x + w > dest.get_width() or y + h > dest.get_height():
        return

    dest_slice = dest_array[x:x+w, y:y+h]

    # Add only where src is brighter
    np.maximum(dest_slice, src_array, out=dest_slice)

    del dest_array

def createLight(screen, radius, position, color):
    blit_add_no_stack(screen, circle_surf(radius, color), (position[0] - radius,position[1] - radius))

def cheapLight(screen, radius, position, color):
    screen.blit(circle_surf(radius, color), (position[0] - radius,position[1] - radius), special_flags=pygame.BLEND_RGB_ADD)

def darkenScreen(screen, darkenBy):
    screen.blit(rect_surf(screen.get_size()[0], screen.get_size()[1], (darkenBy, darkenBy,darkenBy)),(0,0), special_flags=pygame.BLEND_RGB_SUB)
