# Sunny Studios Project

#region Imports
import pygame
import random
import numpy as np
import math
from pygame import mixer
import copy
import os
import json


import pygame.sprite

import Modules.particleSystem as ps
import Modules.lighting as lt
import Modules.shaders as sh

# ---------------------------------- Set Up ----------------------------------
#region Set Up

SCREEN_WIDTH = 1920
SCREEN_HEIGHT = 1200

elapsedTime = 0

cameraPosition = [0,0]
globalPosition = [0,0]

screenOffset = [0,0]

clickUsed = False


# initial save data values
saveData = {
    'SavePresent': False,
    'Settings': {
        'Particles': 'High',
        'ShowFPS': True,
        'FPS Cap': 60,
        'MusicVolume': 0.5,
    },
}

try:
    # the file already exists
    with open('SavedData.txt') as load_file:
        saveData = json.load(load_file)
except:
    # create the file and store initial values
    with open('SavedData.txt', 'w') as store_file:
        json.dump(saveData, store_file)


# ---------------------------------- Functions ----------------------------------
#region Functions
def clamp(value, min_value, max_value):
    return max(min_value, min(value, max_value))

def SinWave(Speed, Size, Offset):
    global elapsedTime
    return((Size * math.sin(elapsedTime * (Speed * 0.8)))+Offset)

def Lerp(a, b, t):
    return(a + ((b - a) * (t*2)))

def recolor_non_transparent(surface, new_color):
    # Convert surface to include per-pixel alpha if it doesn't already
    surface = surface.convert_alpha()

    # Extract the pixels as a 3D array
    arr = pygame.surfarray.pixels3d(surface)
    alpha = pygame.surfarray.pixels_alpha(surface)

    # Create a color array
    r, g, b = new_color
    mask = alpha > 0
    arr[..., 0][mask] = r
    arr[..., 1][mask] = g
    arr[..., 2][mask] = b

    # Unlock the surface
    del arr
    del alpha

    return surface

def point_collides_with_group(point, group):
    dummy = pygame.sprite.Sprite()
    dummy.rect = pygame.Rect(point[0], point[1], 1, 1)  # A 1x1 rect at the point
    return pygame.sprite.spritecollide(dummy, group, dokill = False)


WaitIndex = {}
def Wait(WaitName, Time, dt):
    global WaitIndex
    result = False
    if (WaitIndex.get(WaitName)): # Wait is currently Running
        WaitIndex[WaitName] += dt
        if(WaitIndex[WaitName] >= Time):
            result = True
            del WaitIndex[WaitName]
    else:
        WaitIndex[WaitName] = dt
    return(result)


def SaveData():
    with open('SavedData.txt', 'w') as store_data:
        json.dump(saveData, store_data)




def ChangeGameState(NewState, floorGenOptional = 'Normal'):
    global GameState
    GameState = NewState






# --- Transition Handling ---
#region Transitions

def Transition(NewState, floorGenOptional = 'Normal'):
    global transitionStatus, screenTransitionTo
    transitionStatus = 'Start'
    screenTransitionTo = [NewState, floorGenOptional]
    screenDarkness = 0


screenDarkness = 0
transitionStatus = 'None'
screenTransitionTo = []
def handleTransition(dt):
    global transitionStatus, screenDarkness, screenTransitionTo
    if (transitionStatus == 'Start'):
        screenDarkness = Lerp(screenDarkness, 260, dt * 1.2)
        if (screenDarkness >= 255):
            screenDarkness = 255
            transitionStatus = 'Ending'
            ChangeGameState(screenTransitionTo[0], screenTransitionTo[1])
            screenTransitionTo = []
    elif (transitionStatus == 'Ending'):
        screenDarkness = Lerp(screenDarkness, -5, dt * 1.2)
        if (screenDarkness <= 0):
            screenDarkness = 0
            transitionStatus = 'None'

    lt.darkenScreen(sh.display, screenDarkness)
# --- Transition Handling ---




#---------------------------------- fonts ----------------------------------
#region Fonts
systemFont = None
def CreateFonts():
    global systemFont
    systemFont = pygame.font.SysFont(None, 36)  

#---------------------------------- Mouse ----------------------------------
#region Mouse

mouseCursor = pygame.surface.Surface((0,0))
MousePos = [0,0]

#---------------------------------- Music ----------------------------------
#region Music

# rockMusicFolder = "Assets/Sounds/Music/Rock"
playlists = {
    # 'Rock':[os.path.join(rockMusicFolder, f) for f in os.listdir(rockMusicFolder) if f.endswith('.mp3') or f.endswith('.ogg')],
    }
currentPlaylist = None
lastPlayed = None

def SetMouse(Image):
    global mouseCursor
    mouseCursor = pygame.image.load(Image).convert_alpha()
    mouseCursor = pygame.transform.scale_by(mouseCursor, 0.2)

def changePlaylist(new):
    global lastPlayed, currentPlaylist
    if not currentPlaylist == new:
        lastPlayed = None
        currentPlaylist = new
        pygame.mixer.music.fadeout(500)
        playNextSong()

def stopMusic():
    global lastPlayed, currentPlaylist
    lastPlayed = None
    currentPlaylist = None
    pygame.mixer.music.fadeout(500)


def playNextSong():
    global lastPlayed,currentPlaylist
    if currentPlaylist:
        if lastPlayed == None:
            lastPlayed = random.randint(0,len(playlists[currentPlaylist])-1)
        else:
            lastPlayed += 1
            if lastPlayed >= len(playlists[currentPlaylist]):
                lastPlayed = 0
        pygame.mixer.music.load(playlists[currentPlaylist][lastPlayed])
        
        pygame.mixer.music.play(fade_ms=500)

def DynamicVolume(position):
    dx = (SCREEN_WIDTH/2) - (position[0] + screenOffset)
    dy = (SCREEN_HEIGHT/2) - (position[1] + screenOffset)
    distance = math.hypot(dx, dy)

    # Clamp and invert the distance value
    normalized = max(0, min(1, 1 - (distance / 4000)))
    return(normalized)

# ---------------------------------- Objects ----------------------------------
#region Objects


class Button(pygame.sprite.Sprite):
    def __init__(self, ButtonName,color, textColor, Text, Size, Position, font, cooldown, boundTo):
        super(Button,self).__init__()
        self.image = pygame.image.load(r"Assets\UI\DEFbutton2.png").convert_alpha()
        self.color = color
        self.size = Size
        self.image = pygame.transform.scale_by(self.image, self.size)
        self.image = recolor_non_transparent(self.image, self.color)
        self.text = font.render(Text, True, textColor)
        self.image.blit(self.text, ((self.image.get_size()[0]/2) - (self.text.get_size()[0]/2),(self.image.get_size()[1]/2)  - (self.text.get_size()[1]/2)))
        self.Position = Position
        self.rect = self.image.get_rect()
        self.rotation = 3
        self.name = ButtonName
        self.maxCooldown = cooldown
        self.OnCooldown = 0
        self.pressedSound = mixer.Sound(r'Assets\Sounds\Keyclick.mp3')
        self.hoverSound = mixer.Sound(r'Assets\Sounds\sharpClick.mp3')
        self.hoverSound.set_volume(0.5)
        self.hovering = False
        self.boundTo = boundTo
    def Update(self, currentFrame, deltaTime):
        self.OnCooldown -= deltaTime
        # self.rotation = SinWave(1.1, 2, 2)
        self.rect = self.image.get_rect(
            center=((self.Position[0]), (self.Position[1]))
        )
    def ButtonUpdate(self, currentFrame, deltaTime, MousePos, MouseKeys, KeysPressed, joystickInUse):
        global clickUsed
        if not self.boundTo == False:
            self.rect = self.image.get_rect(
                center=((self.Position[0] + (self.boundTo.image.get_width()/2)) - (self.image.get_width()/2),
                         (self.Position[1] + (self.boundTo.image.get_height()/2)) - (self.image.get_height()))
            )

        result = False
        if (self.rect.collidepoint(MousePos)) and (self.boundTo == False or self.boundTo.Hidden == 0):
            if self.hovering == False:
                self.hovering = True
                self.hoverSound.play()
            self.image = pygame.image.load(r"Assets\UI\DEFbutton1.png").convert_alpha()

            clicked = False
            if not joystickInUse == '':
                clicked = joystickInUse.get_button(0)
            else:
                clicked = MouseKeys[0]

            if (clicked) and self.OnCooldown <= 0 and clickUsed == False:
                clickUsed = True
                self.OnCooldown = self.maxCooldown
                result= self.name
                self.pressedSound.play()
        else:
            if self.hovering == True:
                self.hoverSound.play()
                self.hovering = False

            self.image = pygame.image.load(r"Assets\UI\DEFbutton2.png").convert_alpha()
        self.image = pygame.transform.scale_by(self.image, self.size * clamp((self.maxCooldown - self.OnCooldown), 0.8, 1))
        self.image = recolor_non_transparent(self.image, self.color)

        text = pygame.transform.scale_by(self.text, clamp((self.maxCooldown - self.OnCooldown), 0.8, 1))

        self.image.blit(text, ((self.image.get_size()[0]/2) - (text.get_size()[0]/2),(self.image.get_size()[1]/2)  - (text.get_size()[1]/2)))
        return(result), False
    
    
class Slider(pygame.sprite.Sprite):
    def __init__(self, ButtonName,color, Size, Position, boundTo, totalValue, currentValue):
        super(Slider,self).__init__()
        self.color = color
        self.size = Size
        self.Position = Position

        self.bar = pygame.image.load(r"Assets\UI\DEFSliderBar.png").convert_alpha()
        # self.bar = pygame.transform.scale_by(self.bar, self.size)
        self.bar = recolor_non_transparent(self.bar, self.color)

        self.button = pygame.image.load(r"Assets\UI\DEFbutton2.png").convert_alpha()
        self.button = pygame.transform.rotate(self.button, 90)
        self.button = pygame.transform.scale_by(self.button, self.size)
        self.button = recolor_non_transparent(self.button, self.color)

        self.clickedButton = pygame.image.load(r"Assets\UI\DEFbutton1.png").convert_alpha()
        self.clickedButton = pygame.transform.rotate(self.clickedButton, 90)
        self.clickedButton = pygame.transform.scale_by(self.clickedButton, self.size)
        self.clickedButton = recolor_non_transparent(self.clickedButton, self.color)

        self.activeButton = self.button

        self.image = pygame.Surface((500, self.button.get_height())).convert_alpha()
        self.image.fill((0,0,0,0))

        self.rect = self.image.get_rect()
        self.rotation = 0


        self.OGvalue = totalValue
        self.offset = currentValue / totalValue

        self.name = ButtonName
        self.pressedSound = mixer.Sound(r'Assets\Sounds\Keyclick.mp3')
        self.hoverSound = mixer.Sound(r'Assets\Sounds\sharpClick.mp3')
        self.hoverSound.set_volume(0.5)
        self.dragging = False
        self.boundTo = boundTo
    def Update(self, currentFrame, deltaTime):
        self.rect = self.image.get_rect(
            center=((self.Position[0]), (self.Position[1]))
        )
    def ButtonUpdate(self, currentFrame, deltaTime, MousePos, MouseKeys, KeysPressed, joystickInUse):
        global clickUsed
        self.image.fill((0,0,0,0))

        self.image.blit(self.bar, (self.image.get_width()/2 - (self.bar.get_width()/2) - 20
            ,self.image.get_height()/2 - (self.bar.get_height()/2)))
        
        buttonCornerX = 50 +((self.image.get_width() -150)* self.offset)
        buttonCornerY = self.image.get_height()/2
        buttonRect = self.activeButton.get_rect(
            center = (buttonCornerX, buttonCornerY)
        )
        self.image.blit(self.activeButton, buttonRect)

        if not self.boundTo == False:
            boundPositionX = (self.Position[0] + (self.boundTo.position[0]-(self.boundTo.image.get_width()/2))) - self.image.get_width()/2
            boundPositionY = (self.Position[1] + (self.boundTo.position[1]-(self.boundTo.image.get_height()/2)))
            buttonRect = self.activeButton.get_rect(
                center=(boundPositionX+buttonCornerX,
                        boundPositionY+buttonCornerY)
            )

        if (buttonRect.collidepoint(MousePos)) and self.dragging == False: # check if drag initates
            clicked = False
            if not joystickInUse == '':
                clicked = joystickInUse.get_button(0)
            else:
                clicked = MouseKeys[0]

            if clicked and clickUsed == False:
                clickUsed = True
                self.dragging = True
                self.hoverSound.play()
                self.activeButton = self.clickedButton.copy()


        if self.dragging == True:
            clicked = False
            if not joystickInUse == '':
                clicked = joystickInUse.get_button(0)
            else:
                clicked = MouseKeys[0]

            if not clicked:
                self.dragging = False
                self.pressedSound.play()
                self.activeButton = self.button.copy()

            if boundPositionX + buttonCornerX> MousePos[0] + 20:
                self.offset -= 0.05
            elif boundPositionX + buttonCornerX < MousePos[0] - 20:
                self.offset += 0.05
            self.offset = clamp(self.offset, 0, 1)
            

        return(self.name), self.OGvalue * self.offset

class ScreenShot(pygame.sprite.Sprite):
    def __init__(self):
        super(ScreenShot,self).__init__()
        self.rotation = 0
        self.image = sh.display.copy()
        self.rect = self.image.get_rect(
            center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2)
        )
    def Update(self, currentFrame, deltaTime):
        None

class UIBox(pygame.sprite.Sprite):
    def __init__(self, Title, font, fontColor, position = 'NA'):
        super(UIBox,self).__init__()
        self.image = pygame.image.load(r"Assets\UI\DEFuiBox1.png").convert_alpha()
        self.image = pygame.transform.scale_by(self.image, 3)
        self.text = font.render(Title, True, fontColor)
        self.image.blit(self.text, (100,50))
        self.preloadImage = self.image.copy()
        self.rect = self.image.get_rect()
        self.rotation = -4
        self.Hidden = 0
        if position == 'NA':
            self.position = ((SCREEN_WIDTH/2), (SCREEN_HEIGHT/2))
        else:
            self.position = position
        self.UIContents = []
    def Update(self, currentFrame, deltaTime):

        #reset the image
        self.image = self.preloadImage.copy()

        # self.rotation = SinWave(0.9, 1, -4)
        self.rect = self.image.get_rect(
            center=(self.position[0] - (self.Hidden * SCREEN_WIDTH), self.position[1])
        )
        for i in range(len(self.UIContents)):
            obj = self.UIContents[i]
            obj.Update(currentFrame, deltaTime)
            self.image.blit(pygame.transform.rotate(obj.image, obj.rotation), obj.rect)

    def ChangeHidden(self, new):
        self.Hidden = new
    def ToggleHidden(self):
        if (self.Hidden == 1):
            self.Hidden = 0
        else:
            self.Hidden = 1

# ---------------------------------- Game State ----------------------------------
#region Game State


GameState = "Loading"
GameStates = {
    "Loading":[pygame.sprite.Group(),pygame.sprite.Group()],
    "Loading2":[pygame.sprite.Group(),pygame.sprite.Group()],
    # "Game": [pygame.sprite.Group(),pygame.sprite.Group()],
    # "DeadPause": [pygame.sprite.Group(),pygame.sprite.Group(), (0,0,0)],
}
defaultBG = (100,100,100)