# Sunny Studios Project


# ----------------------------- Imports -----------------------------
#region Imports
import sys
import os
import json
import pygame
from array import array
import numpy as np
import tkinter as tk
import math
import random
from pygame import mixer
import pygame.sprite
import copy

from pygame.locals import *
joysticks = {}

import Modules.particleSystem as ps
import Modules.shaders as sh
import Modules.lighting as lt
import Modules.objectManager as om
import Modules.animations as anim


# ----------------------------- Project Set Up -----------------------------
#region Set Up

pygame.init()
pygame.joystick.init()

pygame.mixer.set_num_channels(32)  # Increase to 32 channels, or however many you need

root = tk.Tk()
root.withdraw()  # Hide the main window
Monitor_width = root.winfo_screenwidth()
Monitor_height = root.winfo_screenheight()

om.SCREEN_WIDTH = 1920
om.SCREEN_HEIGHT = 1200

sh.SetUpScreen(om.SCREEN_WIDTH, om.SCREEN_HEIGHT)
pygame.display.set_caption("SS - Empty Project")
pygame.display.set_icon(pygame.image.load(r"Assets\Logos\sunnyStudiosLogo.png"))

ps.GenRateChange(om.saveData['Settings']['Particles'])

om.CreateFonts()

clock = pygame.time.Clock()

# --- Music
MUSIC_END = pygame.USEREVENT + 1
pygame.mixer.music.set_endevent(MUSIC_END)

pygame.mixer.music.set_volume(om.saveData['Settings']['MusicVolume'])



# ----------------------------- Functions -----------------------------
#region Functions

def GameQuit():
    global Running

    # --- Handle Saving ---

    om.SaveData()

    # --- Finally Quit ---
    Running = False 
    pygame.quit()
    sys.exit() 

def CalculateMousePos():
    # if abs(joystickInUse.get_axis(2)) > 0.2: # sensitivity checking  ---- Controller Mouse Viewing
    #     om.MousePos[0] += joystickInUse.get_axis(2) * ControllerMouseSpeed
    #     om.MousePos[0] = clamp(om.MousePos[0], 0, om.SCREEN_WIDTH)
    # if abs(joystickInUse.get_axis(3)) > 0.2: # sensitivity checking
    #     om.MousePos[1] += joystickInUse.get_axis(3) * ControllerMouseSpeed
    #     om.MousePos[1] = om.clamp(om.MousePos[1], 0, om.SCREEN_HEIGHT)
    # if not joystickInUse.get_button(0):
    #     om.clickUsed = False

    MOUSE_X, MOUSE_Y = pygame.mouse.get_pos()
    scale_x = Monitor_width / sh.display.get_width()
    scale_y = Monitor_height / sh.display.get_height()
    om.MousePos = (MOUSE_X / scale_x, MOUSE_Y / scale_y)
    if not pygame.mouse.get_pressed()[0]:
        om.clickUsed = False

# ----------------------------- Main Loop -----------------------------
#region Main Loop

currentFrame = 0
Running = True
Paused = False
PausedCooldown = 1
while Running:
    dt = clock.tick(om.saveData['Settings']['FPS Cap']) / 1000 
    # ------ Input Collection -------
    #region >Input Collection
    PausedCooldown += dt

    om.screenOffset[0] = -om.cameraPosition[0] + om.globalPosition[0]
    om.screenOffset[1] = -om.cameraPosition[1] + om.globalPosition[1]

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            GameQuit()            
        elif event.type == KEYDOWN:
            if event.key == K_DELETE:
                GameQuit() 
            elif event.key == K_ESCAPE and PausedCooldown > 0.5:
                PausedCooldown = 0
                Paused = not Paused

                if Paused == True: # Just Paused
                    pygame.mixer.pause()
                    pygame.mixer.music.pause()
                elif Paused == False: # Just unpaused
                    pygame.mixer.unpause()
                    pygame.mixer.music.unpause()
        elif event.type == pygame.JOYDEVICEADDED:
            joy = pygame.joystick.Joystick(event.device_index)
            joysticks[joy.get_instance_id()] = joy
        elif event.type == pygame.JOYDEVICEREMOVED:
            del joysticks[event.instance_id]
        elif event.type == MUSIC_END:
            om.playNextSong()
                
    keys_pressed = pygame.key.get_pressed()

    # --- Check if paused ---
    if Paused == True: 
        #region >Paused

        # ------ Pause Menu Screen ------
        sh.display.fill((255,255,255)) # Resets Screen Color
        om.elapsedTime = PausedCooldown

        CalculateMousePos()

    else:
        #region >UnPaused
        # ------ First Steps -------
        currentFrame+=1

        om.elapsedTime += dt

        if 2 < len(om.GameStates[om.GameState]):
            sh.display.fill(om.GameStates[om.GameState][2])
        else:
            sh.display.fill(om.defaultBG) # Resets Screen Color

        # ------ Input Processing -------

        CalculateMousePos()

        # ------ Render items -------
        
        for obj in om.GameStates[om.GameState][0]:
            obj.Update(currentFrame, dt)
            if (obj.rect.colliderect(sh.SCREEN_RECT)):
                sh.display.blit(pygame.transform.rotate(obj.image, obj.rotation), obj.rect)


        # Handle Transtions
        om.handleTransition(dt)

        # Particle Rendering
        ps.HandleParticles(dt, sh.display, sh.SCREEN_RECT)

    #region >Screen Update

    sh.display.blit(om.mouseCursor, om.MousePos)
    if om.saveData['Settings']['ShowFPS'] == True:
        fps = str(int(clock.get_fps()))
        text = om.systemFont.render('FPS: '+fps, 1, (255, 0, 0))
        sh.display.blit(text, (0,0))
    sh.RenderFrame() # Renders Screen
